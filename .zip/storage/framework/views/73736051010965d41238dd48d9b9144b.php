<?php $__env->startSection('content'); ?>
    <!-- Start Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="breadcrumbs-content">
                        <h1 class="page-title d-flex"><?php echo e(__('lang.products')); ?></h1>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12 <?php echo e(app()->getLocale() === 'ar' ? 'd-flex justify-content-end' : 'justify-content-start'); ?>">
                    <ul class="breadcrumb-nav" dir="ltr">
                        <li><a href="<?php echo e(route('home')); ?>"><i class="lni lni-home"></i> <?php echo e(__('lang.home')); ?></a></li>
                        <li><?php echo e(__('lang.products')); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->

    <!-- Start Product Grids -->
    <section class="product-grids section">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-12">
                    <!-- Sidebar -->
                    <div class="product-sidebar">
                        <!-- Search -->
                        <div class="single-widget search">
                            <h3><?php echo e(__('lang.search_product')); ?></h3>
                            <form action="<?php echo e(route('products.index')); ?>" method="GET">
                                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="<?php echo e(__('lang.search_placeholder')); ?>">
                                <button type="submit"><i class="lni lni-search-alt"></i></button>
                            </form>
                        </div>

                        <!-- Categories -->
                        <div class="single-widget">
                            <h3><?php echo e(__('lang.categories')); ?></h3>
                            <ul class="list">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('products.filterByCategory', $cat->id)); ?>">
                                            <?php echo e(app()->getLocale() === 'ar' ? $cat->ar_name : $cat->en_name); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9 col-12">
                    <div class="product-grids-head">
                        <div class="product-grid-topbar">
                            <div class="row align-items-center">
                                <div class="col-lg-6 col-md-8 col-12">
                                    <div class="product-sorting">
                                        <form action="<?php echo e(route('products.index')); ?>" method="GET">
                                            <input type="hidden" name="search" value="<?php echo e(request('search')); ?>">
                                            <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
                                            <label for="sorting">Sort by:</label>
                                            <select class="form-control" name="sort" onchange="this.form.submit()">
                                                <option value="">Default</option>
                                                <option value="price_low_high" <?php echo e(request('sort') == 'price_low_high' ? 'selected' : ''); ?>>Price: Low to High</option>
                                                <option value="price_high_low" <?php echo e(request('sort') == 'price_high_low' ? 'selected' : ''); ?>>Price: High to Low</option>
                                                <option value="name_asc" <?php echo e(request('sort') == 'name_asc' ? 'selected' : ''); ?>>Name: A-Z</option>
                                                <option value="name_desc" <?php echo e(request('sort') == 'name_desc' ? 'selected' : ''); ?>>Name: Z-A</option>
                                            </select>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Products Grid -->
                        <div class="row">
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-lg-4 col-md-6 col-12">
                                    <div class="single-product">
                                        <div class="product-image">
                                            <?php
                                                $primaryImage = collect($product->images)->firstWhere('primary', true)['url'] ?? $product->images[0]['url'] ?? 'path/to/default.jpg';
                                            ?>
                                            <img src="<?php echo e($primaryImage); ?>" alt="<?php echo e($product->en_name); ?>" height="250">
                                        </div>
                                        <div class="product-info">
                                            <h4 class="title">
                                                <a href="<?php echo e(route('product.details',$product->id)); ?>"><?php echo e(app()->getLocale() === 'ar' ? $product->ar_name : $product->en_name); ?></a>
                                            </h4>
                                            <div class="price">
                                                $<?php echo e(number_format($product->price, 2)); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>No products found.</p>
                            <?php endif; ?>
                        </div>

                        <!-- Pagination -->
                        <div class="pagination left">
                            <?php echo e($products->withQueryString()->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Product Grids -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\medical-commerce\resources\views/front/all-products.blade.php ENDPATH**/ ?>
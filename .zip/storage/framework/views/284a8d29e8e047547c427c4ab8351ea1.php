<?php $__env->startSection('content'); ?>
<?php if(app()->getLocale() === 'ar'): ?> <!-- Assuming 'ar' is your RTL language -->
<style>
    .carousel-control-prev {
        right: auto;
        left: 0;
    }

    .carousel-control-next {
        left: auto;
        right: 0;
    }

    .carousel-control-prev-icon {
        transform: scaleX(-1);
    }

    .carousel-control-next-icon {
        transform: scaleX(1);
    }
</style>
<?php endif; ?>

<div class="card p-3">
    <div class="card-header d-flex justify-content-between">
        <h1><?php echo e(__('lang.product_list')); ?></h1>
        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary"><?php echo e(__('lang.add_product')); ?></a>
    </div>

    <table class="table table-striped">
        <thead>
            <tr>
                <th><?php echo e(__('lang.image')); ?></th>
                <th><?php echo e(__('lang.ar_name')); ?></th>
                <th><?php echo e(__('lang.en_name')); ?></th>
                <th><?php echo e(__('lang.category')); ?></th>
                <th><?php echo e(__('lang.price')); ?></th>
                <th><?php echo e(__('lang.quantity')); ?></th>
                <th><?php echo e(__('lang.actions')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <!-- Primary Image -->
                    <td>
                        <?php
                            // Decode the images column if it's a JSON string
                            $images = is_string($product->images) ? json_decode($product->images, true) : $product->images;

                            // Ensure $images is an array and contains data
                            if (is_array($images) && count($images) > 0) {
                                // Find the primary image
                                $primaryImage = collect($images)->firstWhere('primary', true);

                                // Fallback to the first image if no primary is set
                                if (!$primaryImage) {
                                    $primaryImage = $images[0];
                                }
                            } else {
                                $primaryImage = null;
                            }
                        ?>

                        <?php if($primaryImage && isset($primaryImage['url'])): ?>
                            <img src="<?php echo e($primaryImage['url']); ?>" alt="<?php echo e($product->en_name); ?>" class="img-thumbnail fixed-height">
                        <?php else: ?>
                            <span><?php echo e(__('lang.no_image')); ?></span>
                        <?php endif; ?>
                    </td>

                    <td><?php echo e($product->ar_name); ?></td>
                    <td><?php echo e($product->en_name); ?></td>
                    <td>
                        <?php echo e($product->category ? (app()->getLocale() == 'ar' ? $product->category->ar_name : $product->category->en_name) : __('lang.no_category')); ?>

                    </td>
                    <td>$<?php echo e($product->price); ?></td>
                    <td><?php echo e($product->quantity); ?></td>
                    <td>
                        <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#productImagesModal<?php echo e($product->id); ?>">
                            <?php echo e(__('lang.view_images')); ?>

                        </button>
                        <a href="<?php echo e(route('admin.products.edit', $product)); ?>" class="btn btn-warning btn-sm"><?php echo e(__('lang.edit')); ?></a>
                        <form action="<?php echo e(route('admin.products.destroy', $product)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('lang.confirm_delete')); ?>')"><?php echo e(__('lang.delete')); ?></button>
                        </form>
                    </td>
                </tr>

                <!-- Modal for Images -->
                <div class="modal fade" id="productImagesModal<?php echo e($product->id); ?>" tabindex="-1" aria-labelledby="productImagesModalLabel<?php echo e($product->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="productImagesModalLabel<?php echo e($product->id); ?>"><?php echo e(__('lang.product_images')); ?>: <?php echo e($product->ar_name); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php echo e(__('lang.close')); ?>"></button>
                            </div>
                            <div class="modal-body">
                                <?php if(is_array($images) && count($images) > 0): ?>
                                    <div id="carousel<?php echo e($product->id); ?>" class="carousel slide" data-bs-ride="carousel">
                                        <div class="carousel-inner">
                                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                                    <img src="<?php echo e($image['url']); ?>" class="d-block w-100" alt="<?php echo e(__('lang.product_image')); ?>">
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                        <button class="carousel-control-prev" type="button" data-bs-target="#carousel<?php echo e($product->id); ?>" data-bs-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden"><?php echo e(__('lang.previous')); ?></span>
                                        </button>
                                        <button class="carousel-control-next" type="button" data-bs-target="#carousel<?php echo e($product->id); ?>" data-bs-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="visually-hidden"><?php echo e(__('lang.next')); ?></span>
                                        </button>
                                    </div>
                                <?php else: ?>
                                    <p><?php echo e(__('lang.no_images')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>


    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
    .fixed-height {
        height: 50px;
        object-fit: cover;
    }

    .carousel-control-prev,
    .carousel-control-next {
        top: 50%;
        transform: translateY(-50%);
        z-index: 2;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\medical-commerce\resources\views/admin/products/index.blade.php ENDPATH**/ ?>
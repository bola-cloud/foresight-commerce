<?php $__env->startSection('content'); ?>
<div class="card p-3">
    <h1><?php echo e(__('lang.edit_ad')); ?></h1>

    <form action="<?php echo e(route('admin.adsliders.update', $adSlider)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Current Image -->
        <div class="form-group">
            <label for="current_image"><?php echo e(__('lang.current_image')); ?></label>
            <div>
                <img src="<?php echo e(asset('storage/' . $adSlider->image)); ?>" alt="Current Image" width="150">
            </div>
        </div>

        <!-- Upload New Image -->
        <div class="form-group">
            <label for="image"><?php echo e(__('lang.new_image')); ?></label>
            <input type="file" name="image" class="form-control" accept="image/*">
        </div>

        <!-- Brand -->
        <div class="form-group">
            <label for="brand"><?php echo e(__('lang.brand')); ?></label>
            <input type="text" name="brand" class="form-control" value="<?php echo e(old('brand', $adSlider->brand)); ?>" required>
        </div>

        <!-- Arabic Title -->
        <div class="form-group">
            <label for="ar_title"><?php echo e(__('lang.ar_title')); ?></label>
            <input type="text" name="ar_title" class="form-control" value="<?php echo e(old('ar_title', $adSlider->ar_title)); ?>" required>
        </div>

        <!-- English Title -->
        <div class="form-group">
            <label for="en_title"><?php echo e(__('lang.en_title')); ?></label>
            <input type="text" name="en_title" class="form-control" value="<?php echo e(old('en_title', $adSlider->en_title)); ?>" required>
        </div>

        <!-- Arabic Description -->
        <div class="form-group">
            <label for="ar_description"><?php echo e(__('lang.ar_description')); ?></label>
            <textarea name="ar_description" class="form-control"><?php echo e(old('ar_description', $adSlider->ar_description)); ?></textarea>
        </div>

        <!-- English Description -->
        <div class="form-group">
            <label for="en_description"><?php echo e(__('lang.en_description')); ?></label>
            <textarea name="en_description" class="form-control"><?php echo e(old('en_description', $adSlider->en_description)); ?></textarea>
        </div>

        <!-- Price -->
        <div class="form-group">
            <label for="price"><?php echo e(__('lang.price')); ?></label>
            <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e(old('price', $adSlider->price)); ?>">
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary"><?php echo e(__('lang.update')); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\medical-commerce\resources\views/admin/adsliders/edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="card p-3">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><?php echo e(__('lang.ad_list')); ?></h1>
        <a href="<?php echo e(route('admin.adsliders.create')); ?>" class="btn btn-primary mb-3"><?php echo e(__('lang.add_ad')); ?></a>
    </div>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th><?php echo e(__('lang.image')); ?></th>
                <th><?php echo e(__('lang.brand')); ?></th>
                <th><?php echo e(__('lang.ar_title')); ?></th>
                <th><?php echo e(__('lang.en_title')); ?></th>
                <th><?php echo e(__('lang.price')); ?></th>
                <th><?php echo e(__('lang.actions')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $adSliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adSlider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="#" data-bs-toggle="modal" data-bs-target="#imageModal<?php echo e($adSlider->id); ?>">
                            <img src="<?php echo e(asset('storage/' . $adSlider->image)); ?>" alt="Ad Image" class="img-thumbnail fixed-height">
                        </a>
                    </td>
                    <td><?php echo e($adSlider->brand); ?></td>
                    <td><?php echo e($adSlider->ar_title); ?></td>
                    <td><?php echo e($adSlider->en_title); ?></td>
                    <td><?php echo e($adSlider->price ? '$' . $adSlider->price : __('lang.not_available')); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.adsliders.edit', $adSlider)); ?>" class="btn btn-warning btn-sm"><?php echo e(__('lang.edit')); ?></a>
                        <form action="<?php echo e(route('admin.adsliders.destroy', $adSlider)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('lang.confirm_delete')); ?>')">
                                <?php echo e(__('lang.delete')); ?>

                            </button>
                        </form>
                    </td>
                </tr>

                <!-- Image Modal -->
                <div class="modal fade" id="imageModal<?php echo e($adSlider->id); ?>" tabindex="-1" aria-labelledby="imageModalLabel<?php echo e($adSlider->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="imageModalLabel<?php echo e($adSlider->id); ?>"><?php echo e(__('lang.image')); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body text-center">
                                <img src="<?php echo e(asset('storage/' . $adSlider->image)); ?>" alt="Ad Image" class="img-fluid">
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>
    /* Fixed height for images in the table */
    .fixed-height {
        height: 70px; /* Set the fixed height */
        object-fit: cover; /* Ensures the image maintains aspect ratio and fills the area */
    }
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\medical-commerce\resources\views/admin/adsliders/index.blade.php ENDPATH**/ ?>
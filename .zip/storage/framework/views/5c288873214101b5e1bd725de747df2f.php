<?php $__env->startSection('content'); ?>
<div class="card p-3">
    <h1><?php echo e(__('lang.edit_product')); ?></h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Product Name -->
        <div class="form-group">
            <label for="ar_name"><?php echo e(__('lang.ar_name')); ?></label>
            <input type="text" name="ar_name" class="form-control" value="<?php echo e(old('ar_name', $product->ar_name)); ?>" required>
        </div>
        <div class="form-group">
            <label for="en_name"><?php echo e(__('lang.en_name')); ?></label>
            <input type="text" name="en_name" class="form-control" value="<?php echo e(old('en_name', $product->en_name)); ?>" required>
        </div>

        <!-- Category -->
        <div class="form-group">
            <label for="category_id"><?php echo e(__('lang.category')); ?></label>
            <select name="category_id" class="form-control select2" required>
                <option value=""><?php echo e(__('lang.select_category')); ?></option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id', $product->category_id) == $category->id ? 'selected' : ''); ?>>
                        <?php echo e(app()->getLocale() === 'ar' ? $category->ar_name : $category->en_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Price -->
        <div class="form-group">
            <label for="price"><?php echo e(__('lang.price')); ?></label>
            <input type="number" step="0.01" name="price" class="form-control" value="<?php echo e(old('price', $product->price)); ?>" required>
        </div>

        <!-- Quantity -->
        <div class="form-group">
            <label for="quantity"><?php echo e(__('lang.quantity')); ?></label>
            <input type="number" name="quantity" class="form-control" value="<?php echo e(old('quantity', $product->quantity)); ?>" required>
        </div>

        <!-- Description -->
        <div class="form-group">
            <label for="ar_description"><?php echo e(__('lang.ar_description')); ?></label>
            <textarea name="ar_description" class="form-control"><?php echo e(old('ar_description', $product->ar_description)); ?></textarea>
        </div>
        <div class="form-group">
            <label for="en_description"><?php echo e(__('lang.en_description')); ?></label>
            <textarea name="en_description" class="form-control"><?php echo e(old('en_description', $product->en_description)); ?></textarea>
        </div>

        <!-- Features -->
        <div class="form-group">
            <label for="ar_features"><?php echo e(__('lang.ar_features')); ?></label>
            <textarea name="ar_features" class="form-control"><?php echo e(old('ar_features', is_array($product->ar_features) ? implode("\n", $product->ar_features) : $product->ar_features)); ?></textarea>
        </div>

        <div class="form-group">
            <label for="en_features"><?php echo e(__('lang.en_features')); ?></label>
            <textarea name="en_features" class="form-control"><?php echo e(old('en_features', is_array($product->en_features) ? implode("\n", $product->en_features) : $product->en_features)); ?></textarea>
        </div>

        <!-- Manufacturer -->
        <div class="form-group">
            <label for="ar_manufacturer"><?php echo e(__('lang.ar_manufacturer')); ?></label>
            <input type="text" name="ar_manufacturer" class="form-control" value="<?php echo e(old('ar_manufacturer', $product->ar_manufacturer)); ?>">
        </div>
        <div class="form-group">
            <label for="en_manufacturer"><?php echo e(__('lang.en_manufacturer')); ?></label>
            <input type="text" name="en_manufacturer" class="form-control" value="<?php echo e(old('en_manufacturer', $product->en_manufacturer)); ?>">
        </div>

        <!-- Existing Images -->
        <div class="form-group">
            <label><?php echo e(__('lang.existing_images')); ?></label>
            <div class="d-flex flex-wrap gap-2">
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="image-preview">
                        <img src="<?php echo e($image['url']); ?>" alt="Product Image" class="img-thumbnail" style="width: 100px; height: 100px;">
                        <p class="text-center small"><?php echo e($image['primary'] ? __('lang.primary_image') : ''); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- New Images -->
        <div class="form-group">
            <label for="images"><?php echo e(__('lang.new_images')); ?></label>
            <input type="file" class="filepond" name="file" multiple>
        </div>

        <!-- Hidden Inputs for Images -->
        <input type="hidden" name="images" id="uploadedImages">
        <input type="hidden" name="current_images" value="<?php echo e(json_encode($product->images)); ?>">

        <!-- Primary Image Selection -->
        <div class="form-group mt-3">
            <label for="primary_image"><?php echo e(__('lang.primary_image')); ?></label>
            <select name="primary_image" id="primary_image" class="form-control">
                <option value=""><?php echo e(__('lang.select_primary_image')); ?></option>
            </select>
        </div>

        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary"><?php echo e(__('lang.update')); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/filepond/dist/filepond.js"></script>
<script src="https://unpkg.com/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2();
    });
</script>
<script>
    FilePond.registerPlugin(FilePondPluginImagePreview);

    let uploadedImages = [];

    const filePond = FilePond.create(document.querySelector('.filepond'), {
        allowMultiple: true,
        server: {
            process: {
                url: '<?php echo e(route("admin.products.upload")); ?>',
                headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                ondata: (formData) => { formData.append('_token', '<?php echo e(csrf_token()); ?>'); return formData; },
            },
            revert: { url: '<?php echo e(route("admin.products.delete_temp_image")); ?>', headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' }, method: 'DELETE' },
        },
        onprocessfile: (error, file) => {
            if (!error) {
                uploadedImages.push(file.serverId);
                document.getElementById('uploadedImages').value = JSON.stringify(uploadedImages);

                // Clear old primary image options
                const primaryImageDropdown = document.getElementById('primary_image');
                primaryImageDropdown.innerHTML = '';

                // Add new images to the primary image dropdown
                uploadedImages.forEach((image) => {
                    const option = document.createElement('option');
                    option.value = image;
                    option.textContent = image;
                    primaryImageDropdown.appendChild(option);
                });
            }
        },
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('css'); ?>
<link href="https://unpkg.com/filepond/dist/filepond.css" rel="stylesheet" />
<link href="https://unpkg.com/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\medical-commerce\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>
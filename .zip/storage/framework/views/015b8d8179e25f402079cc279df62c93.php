

<?php $__env->startSection('content'); ?>

<div class="card">
    <h1>bola</h1>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\Smart_home\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
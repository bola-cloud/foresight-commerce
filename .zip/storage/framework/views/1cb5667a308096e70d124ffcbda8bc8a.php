<?php $__env->startSection('content'); ?>

    <!-- Start Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="breadcrumbs-content">
                        <h1 class="page-title d-flex"><?php echo e(app()->getLocale() === 'ar' ? $product->ar_name : $product->en_name); ?></h1>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12 <?php echo e(app()->getLocale() === 'ar' ? 'd-flex justify-content-end' : 'justify-content-start'); ?>">
                    <ul class="breadcrumb-nav" dir="ltr">
                        <li><a href=""><i class="lni lni-home"></i> <?php echo e(__('lang.home')); ?></a></li>
                        <li><a href=""><?php echo e(__('lang.shop')); ?></a></li>
                        <li><?php echo e(app()->getLocale() === 'ar' ? $product->ar_name : $product->en_name); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->

    <!-- Start Item Details -->
    <section class="item-details section">
        <div class="container">
            <div class="top-area">
                <div class="row align-items-center">
                    <!-- Product Images -->
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="product-images">
                            <main id="gallery">
                                <?php if(!empty($product->images)): ?>
                                    <div class="main-img">
                                        <img src="<?php echo e(collect($product->images)->firstWhere('primary', true)['url'] ?? $product->images[0]['url']); ?>" height="400" id="current" alt="<?php echo e(app()->getLocale() === 'ar' ? $product->ar_name : $product->en_name); ?>">
                                    </div>
                                    <div class="images">
                                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <img src="<?php echo e($image['url']); ?>" class="img" alt="<?php echo e(app()->getLocale() === 'ar' ? $product->ar_name : $product->en_name); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <!-- Fallback if no images are available -->
                                    <img src="<?php echo e(asset('theme/assets/images/products/default.jpg')); ?>" class="img-thumbnail" alt="No image available">
                                <?php endif; ?>
                            </main>
                        </div>
                    </div>

                    <!-- Product Info -->
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="product-info">
                            <h2 class="title"><?php echo e(app()->getLocale() === 'ar' ? $product->ar_name : $product->en_name); ?></h2>
                            <p class="category"><i class="lni lni-tag"></i> <?php echo e(__('lang.category')); ?>:
                                <a href="#"><?php echo e(app()->getLocale() === 'ar' ? $product->category->ar_name ?? 'غير مصنف' : $product->category->en_name ?? 'Uncategorized'); ?></a>
                            </p>
                            <h3 class="price">$<?php echo e(number_format($product->price, 2)); ?></h3>
                            <p class="info-text"><?php echo e(app()->getLocale() === 'ar' ? $product->ar_description : $product->en_description); ?></p>
                            <div class="bottom-content">
                                <div class="row align-items-end">
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="button cart-button">
                                            <button class="btn" style="width: 100%;"><?php echo e(__('lang.add_to_cart')); ?></button>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="wish-button">
                                            <button class="btn"><i class="lni lni-heart"></i> <?php echo e(__('lang.to_wishlist')); ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Product Details Info -->
            <div class="product-details-info">
                <div class="single-block">
                    <div class="row">
                        <div class="col-lg-6 col-12">
                            <div class="info-body custom-responsive-margin">
                                <h4><?php echo e(__('lang.details')); ?></h4>
                                <p><?php echo e(app()->getLocale() === 'ar' ? $product->ar_description : $product->en_description); ?></p>
                                <h4><?php echo e(__('lang.features')); ?></h4>
                                <ul class="features">
                                    <?php
                                        $features = app()->getLocale() === 'ar'
                                            ? (is_string($product->ar_features) ? json_decode($product->ar_features, true) : $product->ar_features)
                                            : (is_string($product->en_features) ? json_decode($product->en_features, true) : $product->en_features);
                                    ?>

                                    <?php if(!empty($features)): ?>
                                        <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($feature); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <li><?php echo e(__('lang.no_features')); ?></li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-6 col-12">
                            <div class="info-body">
                                <h4><?php echo e(__('lang.specifications')); ?></h4>
                                <ul class="normal-list">
                                    <li><span><?php echo e(__('lang.manufacturer')); ?>:</span> <?php echo e(app()->getLocale() === 'ar' ? $product->ar_manufacturer : $product->en_manufacturer); ?></li>
                                    <li><span><?php echo e(__('lang.price')); ?>:</span> $<?php echo e(number_format($product->price, 2)); ?></li>
                                    <li><span><?php echo e(__('lang.quantity')); ?>:</span> <?php echo e($product->quantity); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- End Item Details -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script type="text/javascript">
    const current = document.getElementById("current");
    const opacity = 0.6;
    const imgs = document.querySelectorAll(".img");
    imgs.forEach(img => {
        img.addEventListener("click", (e) => {
            //reset opacity
            imgs.forEach(img => {
                img.style.opacity = 1;
            });
            current.src = e.target.src;
            //adding class
            //current.classList.add("fade-in");
            //opacity
            e.target.style.opacity = opacity;
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\foresight\resources\views/front/product-details.blade.php ENDPATH**/ ?>
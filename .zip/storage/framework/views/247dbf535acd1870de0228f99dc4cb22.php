<?php $__env->startSection('content'); ?>
<div class="card p-3">
    <h1><?php echo e(__('lang.add_ad')); ?></h1>

    <form action="<?php echo e(route('admin.adsliders.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="image"><?php echo e(__('lang.image')); ?></label>
            <input type="file" name="image" class="form-control" accept="image/*" required>
        </div>

        <div class="form-group">
            <label for="brand"><?php echo e(__('lang.brand')); ?></label>
            <input type="text" name="brand" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="ar_title"><?php echo e(__('lang.ar_title')); ?></label>
            <input type="text" name="ar_title" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="en_title"><?php echo e(__('lang.en_title')); ?></label>
            <input type="text" name="en_title" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="ar_description"><?php echo e(__('lang.ar_description')); ?></label>
            <textarea name="ar_description" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="en_description"><?php echo e(__('lang.en_description')); ?></label>
            <textarea name="en_description" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label for="price"><?php echo e(__('lang.price')); ?></label>
            <input type="number" step="0.01" name="price" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary"><?php echo e(__('lang.submit')); ?></button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\medical-commerce\resources\views/admin/adsliders/create.blade.php ENDPATH**/ ?>
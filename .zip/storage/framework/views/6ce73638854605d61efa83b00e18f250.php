<?php $__env->startSection('content'); ?>
<div class="card p-3">
    <!-- Header Section -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1><?php echo e(__('lang.category_list')); ?></h1>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal"><?php echo e(__('lang.add_category')); ?></button>
    </div>

    <!-- Success Messages -->
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <!-- Category Table -->
    <table class="table table-striped">
        <thead>
            <tr>
                <th><?php echo e(__('lang.ar_category_name')); ?></th>
                <th><?php echo e(__('lang.en_category_name')); ?></th>
                <th><?php echo e(__('lang.actions')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($category->ar_name); ?></td>
                    <td><?php echo e($category->en_name); ?></td>
                    <td>
                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editCategoryModal<?php echo e($category->id); ?>">
                            <?php echo e(__('lang.edit')); ?>

                        </button>
                        <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('<?php echo e(__('lang.confirm_delete')); ?>')">
                                <?php echo e(__('lang.delete')); ?>

                            </button>
                        </form>
                    </td>
                </tr>

                <!-- Edit Category Modal -->
                <div class="modal fade" id="editCategoryModal<?php echo e($category->id); ?>" tabindex="-1" aria-labelledby="editCategoryModalLabel<?php echo e($category->id); ?>" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editCategoryModalLabel<?php echo e($category->id); ?>"><?php echo e(__('lang.edit_category')); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('admin.categories.update', $category)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="mb-3">
                                        <label for="ar_name" class="form-label"><?php echo e(__('lang.ar_name')); ?></label>
                                        <input type="text" name="ar_name" class="form-control" value="<?php echo e($category->ar_name); ?>" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="en_name" class="form-label"><?php echo e(__('lang.en_name')); ?></label>
                                        <input type="text" name="en_name" class="form-control" value="<?php echo e($category->en_name); ?>" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('lang.submit')); ?></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Add Category Modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addCategoryModalLabel"><?php echo e(__('lang.add_category')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('admin.categories.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="ar_name" class="form-label"><?php echo e(__('lang.ar_name')); ?></label>
                            <input type="text" name="ar_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="en_name" class="form-label"><?php echo e(__('lang.en_name')); ?></label>
                            <input type="text" name="en_name" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('lang.submit')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\medical-commerce\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>